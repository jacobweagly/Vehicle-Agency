/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author jweagl2
 */
public class Transactions {
    private TransactionNode head;
    private TransactionNode current;
    
    public Transactions(){
        head = new TransactionNode(null);
        reset();
    }
    
    public void add(Transaction v){
        reset();
        TransactionNode temp = new TransactionNode(v);
        while (hasNext()){
            current = current.getNext();
        }
        current.setNext(temp);  
        reset();
    }
    
    public void reset(){
        current = head;
    }
    
    public boolean hasNext(){
        return current.getNext() != null;                
    }
    
    public TransactionNode getNext(){
        current = current.getNext();
        return current;
    }
}
