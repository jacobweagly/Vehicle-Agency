
package vehicles;

public class SystemInterface {
    private static Rates agency_rates;
    private static Vehicles agency_vehicles;
    private static Accounts agency_accounts;
    private static Transactions transactions_history;
    private static boolean initialized;

    // used to init static variables (in place of a constructor)
    public static void initSystem(Rates r, Vehicles v,  Accounts a, Transactions t) {

            agency_rates = r;
            agency_vehicles = v;
            agency_accounts = a;
            transactions_history = t;
            initialized = true;
    }

    // Note that methods makeReserv, cancelReservation, and addAccount return information
    // that confirms the successful completion of the requested action.
    // vehicle rates-related methods
    public static String[ ] getCarRates() {
        String[] s = {agency_rates.getCarRates().toString()};
        return s;
    }
    
    public static String[ ] getSUVRates() {
        String[] s = {agency_rates.getSUVRates().toString()};
        return s;
    }
    
    public static String[ ] getTruckRates() {
        String[] s = {agency_rates.getTruckRates().toString()};
        return s;
    }

    public static String[ ] updateCarRates(double a, double b, double c, double d, double e) {
        String[] s = {"done"};
        VehicleRates r = new CarRates(a,b,c,d,e);
        agency_rates.setCarRates(r);
        return s;
    }
    
    public static String[ ] updateSUVRates(double a, double b, double c, double d, double e) {
        String[] s = {"done"};
        VehicleRates r = new SUVRates(a,b,c,d,e);
        agency_rates.setSUVRates(r);
        return s;
    }
    
    public static String[ ] updateTruckRates(double a, double b, double c, double d, double e) {
        String[] s = {"done"};
        VehicleRates r = new TruckRates(a,b,c,d,e);
        agency_rates.setTruckRates(r);
        return s;
    }
    
    public static String[ ] estimatedRentalCost(RentalDetails details) {
        String[] s = {agency_rates.calcEstimatedCost(details.getVehicleType(), details.getEstimatedRentalPeriod(), details.getEstimatedNumMiles(), details.isInsured(), details.isPrimeCustomer()) + ""};
        return s;
    }
    
    public static String[ ] processReturnedVehicle(String vin, int num_days_used, int num_miles_driven) {
        String[] s = {"done"};
        Vehicle v = agency_vehicles.getVehicle(vin);
        String acct = v.getReservation().getCreditCardNum();        // acct
        String typeVehicle = v.getClass().getName().substring(9);   // type
        String rent = "";
        if(num_days_used <= 7){
            rent = "D" + num_days_used;
        }
        if(num_days_used > 7 && num_days_used < 30){
            rent = "W" + (num_days_used / 7);
        }
        if(num_days_used >= 30){
            rent = "M" + (num_days_used / 30);
        }                                                           // rent
        int vType;
        switch(v.getClass().getName()){
            case "vehicles.Car" :
                vType = 0;
                break;
            case "vehicles.Suv" :
                vType = 1;
                break;
            case "vehicles.Truck" : 
                vType = 2;
                break;
        }
        String cost = "" + agency_rates.calcActualCost(v.getCost() , num_days_used, num_miles_driven, true, true);
        try {
                String comp = agency_accounts.getAccount(acct).getCompanyName();    // comp
                transactions_history.add(new Transaction(acct, comp, typeVehicle, rent, cost));
        }
        catch (Exception ex){}
        return s;
    }
    
    public static String[ ] getAvailCars() {
        agency_vehicles.reset(); 
        int count = 0;
        while (agency_vehicles.hasNext()){
            if(agency_vehicles.getCurrent().getVehicle().getClass().getName() == "vehicles.Car" && !agency_vehicles.getCurrent().getVehicle().isReserved()){
                count++;
            }
        }
        String[] s = new String[count];
        agency_vehicles.reset();
        count = 0;
        while (agency_vehicles.hasNext()){
            if(agency_vehicles.getCurrent().getVehicle().getClass().getName() == "vehicles.Car" && !agency_vehicles.getCurrent().getVehicle().isReserved()){
                s[count] = agency_vehicles.getCurrent().getVehicle().toString();
                count++;
            }
        }
        return s;
    }
    
    public static String[ ] getAvailSUVs() {
        agency_vehicles.reset(); 
        int count = 0;
        while (agency_vehicles.hasNext()){
            if(agency_vehicles.getCurrent().getVehicle().getClass().getName() == "vehicles.Suv" && !agency_vehicles.getCurrent().getVehicle().isReserved()){
                count++;
            }
        }
        String[] s = new String[count];
        agency_vehicles.reset();
        count = 0;
        while (agency_vehicles.hasNext()){
            if(agency_vehicles.getCurrent().getVehicle().getClass().getName() == "vehicles.Suv" && !agency_vehicles.getCurrent().getVehicle().isReserved()){
                s[count] = agency_vehicles.getCurrent().getVehicle().toString();
                count++;
            }
        }
        return s;
    }
    
    public static String[ ] getAvailTrucks() {
        agency_vehicles.reset(); 
        int count = 0;
        while (agency_vehicles.hasNext()){
            if(agency_vehicles.getCurrent().getVehicle().getClass().getName() == "vehicles.Truck" && !agency_vehicles.getCurrent().getVehicle().isReserved()){
                count++;
            }
        }
        String[] s = new String[count];
        agency_vehicles.reset();
        count = 0;
        while (agency_vehicles.hasNext()){
            if(agency_vehicles.getCurrent().getVehicle().getClass().getName() == "vehicles.Truck" && !agency_vehicles.getCurrent().getVehicle().isReserved()){
                s[count] = agency_vehicles.getCurrent().getVehicle().toString();
                count++;
            }
        }
        return s;
    }
    
    public static String[ ] getAllVehicles() {
        agency_vehicles.reset();
        int count = 0;
        while (agency_vehicles.hasNext()){
            count++;
        }
        String[] s = new String[count];
        agency_vehicles.reset();
        count = 0;
        while (agency_vehicles.hasNext()){
            s[count] = agency_vehicles.getCurrent().getVehicle().toString();
            count++;
        }
        return s;
    }

    public static String[ ] makeReservation(ReservationDetails details) {
        String[] s = {"done"};
        System.out.println("HK4GM4565GD");
        System.out.println(details.getVIN());
        System.out.println(agency_vehicles.getVehicle("HK4GM4565GD"));
        System.out.println(agency_vehicles.getVehicle(details.getVIN()));
        agency_vehicles.getVehicle(details.getVIN()).reserve(new Reservation(details.getAcct_num(), details.getRentalPeriod() , details.isInsured()));
        switch(agency_vehicles.getVehicle(details.getVIN()).getClass().getName()){
            case "vehicles.Car" :
                agency_vehicles.getVehicle(details.getVIN()).setCost(agency_rates.getCarRates().cloneAsCostType());
                break;
            case "vehicles.Suv" :
                agency_vehicles.getVehicle(details.getVIN()).setCost(agency_rates.getSUVRates().cloneAsCostType());
                break;
            case "vehicles.Truck" : 
                agency_vehicles.getVehicle(details.getVIN()).setCost(agency_rates.getTruckRates().cloneAsCostType());
                break;
        }
        return s;
    }
    
    public static String[ ] cancelReservation(String vin) {
        String[] s = {"done"};
        agency_vehicles.getVehicle(vin).cancelReservation();
        return s;
    }
    
    public static String[ ] getReservation(String vin) {
        String[] s = {agency_vehicles.getVehicle(vin).getReservation().toString()};
        return s;
    }
    
    public static String[ ] getAllReservations() {
        agency_vehicles.reset();
        int count = 0;
        while (agency_vehicles.hasNext()){
            if(agency_vehicles.getCurrent().getVehicle().getReservation() != null){
                count++;
            }
        }
        String[] s = new String[count];
        agency_vehicles.reset();
        count = 0;
        while (agency_vehicles.hasNext()){
            if(agency_vehicles.getCurrent().getVehicle().getReservation() != null){
                s[count] = agency_vehicles.getCurrent().getVehicle().getReservation().toString();
                count++;
            }
        }
        return s;    
    }

    public static String[ ] addAccount(String acct_num, String company_name, boolean prime_cust) {
        String[] s = {"done"};
        agency_accounts.add(new Account(acct_num, company_name, prime_cust));
        return s;
    }
    
    public static String[ ] getAccount(String acct_num) {
        try{
        String[] s = {agency_accounts.getAccount(acct_num).toString()};
        return s;
        }
        catch(InvalidAcctNumException ex){
            System.out.print(ex);
        }
        catch(AccountNumberNotFoundException ex){
            System.out.print(ex);
        }
        return null;
    }
    
    public static String[ ] getAllAccounts() {
        agency_accounts.reset();
        int count = 0;
        while(agency_accounts.hasNext()){
            agency_accounts.getNext();
            count++;
        }
        String[] s = new String[count];
        agency_accounts.reset();
        count = 0;
        while(agency_accounts.hasNext()){
            s[count] = agency_accounts.getNext().getAccount().toString();
            count++;
        }
        return s;
    }

    public static String[ ] getAllTransactions() {
        transactions_history.reset();
        int count = 0;
        while(transactions_history.hasNext()){
            transactions_history.getNext();
            count++;
        }
        String[] s = new String[count];
        transactions_history.reset();
        count = 0;
        while(transactions_history.hasNext()){
            s[count] = transactions_history.getNext().getTransaction().toString();
            count++;
        }
        return s;
    }
    
    public static boolean initialized(){
        return initialized;
    }
}