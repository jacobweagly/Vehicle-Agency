
package vehicles;

public class Truck extends Vehicle{
    private int load;
    public Truck(String d, int m, String v, int l){
        super(d, m, v);
        load = l;
    }
    public String toString(){
        return getDescript() + " (Truck) MPG: " + getMPG() + " Load Capacity: " + getLoadCapacity() + " lbs. VIN: " + getVIN();
    }
    public int getLoadCapacity(){
        return load;
    }
}
