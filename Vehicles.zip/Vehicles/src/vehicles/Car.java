
package vehicles;

public class Car extends Vehicle{
    private int capacity;
    public Car(String d, int m, String v, int c){
        super(d, m, v);
        capacity = c;
    }
    public String toString(){
        return getDescript() + " (Car) MPG: " + getMPG() + " Seating: " + getSeatingCapacity() + " VIN: " + getVIN();
    }
    
    public int getSeatingCapacity(){
        return capacity;
    }
}
