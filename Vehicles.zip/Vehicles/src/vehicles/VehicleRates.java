
package vehicles;

public abstract class VehicleRates {
        private double daily_rate, weekly_rate, monthly_rate, mileage_chrg, daily_insur_rate;
    
	public VehicleRates(double daily_rate, double weekly_rate, double monthly_rate, double mileage_chrg, double daily_insur_rate){
            this.daily_rate = daily_rate;
            this.weekly_rate = weekly_rate;
            this.monthly_rate = monthly_rate;
            this.mileage_chrg = mileage_chrg;
            this.daily_insur_rate = daily_insur_rate;
        }
	public double getDailyRate()		// cost per day
        {
            return daily_rate;
        }
	public double getWeeklyRate()       	// cost per week
        {
            return weekly_rate;
        }
	public double getMonthlyRate()       	// cost per month
        {
            return monthly_rate;
        }
	public double getMileageChrg()      	// cost per mile, based on vehicle type  
        {
            return mileage_chrg;
        }
	public double getDailyInsurRate()  	// insurance cost (per day)
        {
            return daily_insur_rate;
        }
	public Cost cloneAsCostType()         // creates a copy a VehicleRates object, returned as type Cost
        {
            return new ClonedCost(daily_rate, weekly_rate, monthly_rate, mileage_chrg, daily_insur_rate);
        }
        public abstract String toString();
}
