
package vehicles;

public class RentalDetails {
    private int vehicleType;
    String estimatedRentalPeriod;
    private int estimatedNumMiles;
    private boolean dailyInsur;
    private boolean primeCustomer;
    
            
    public RentalDetails(int v, String rp, int mi, boolean d, boolean p){
        vehicleType = v;
        estimatedRentalPeriod = rp;
        estimatedNumMiles = mi;
        dailyInsur = d;
        primeCustomer = p;
    }
    
    public int getVehicleType(){
        return vehicleType;
    }
    public String getEstimatedRentalPeriod(){
        return estimatedRentalPeriod;
    }
    public int getEstimatedNumMiles(){
        return estimatedNumMiles;
    }
    public boolean isInsured(){
        return dailyInsur;
    }
    public boolean isPrimeCustomer(){
        return primeCustomer;
    }
}
