
package vehicles;

public interface Cost {
    public double getDailyRate();	
    public double getWeeklyRate();  
    public double getMonthlyRate();
    public double getMileageChrg();
    public double getDailyInsurRate();
}
