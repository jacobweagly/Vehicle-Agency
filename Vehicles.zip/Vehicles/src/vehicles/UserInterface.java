
package vehicles;

public interface UserInterface {
    public void start();
}
