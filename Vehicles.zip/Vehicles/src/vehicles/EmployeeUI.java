
package vehicles;

import java.util.*;
import java.io.*;

public class EmployeeUI implements UserInterface {
	
	// no constructor needed, calls static methods of the SystemInterface
	// starts a “command loop” that repeatedly: (a) displays a menu of options, (b) gets the selected
        // option from the user, and (c) executes the corresponding command.

 	public void start() {

	int selection;
        Scanner input = new Scanner(System.in);
	boolean quit = false;

	// command loop
	while(!quit) {
            
		displayMenu();
		selection = getSelection(input);
                quit = selection == 8;
		execute(selection, input, quit);
	}
      }
	
      private void execute(int selection, Scanner input, boolean quit) {

        int veh_type;
	String vin, acct_num;  String[] display_lines = {""};
	RentalDetails rental_details;  ReservationDetails reserv_details;

	switch(selection) {

		// display rental rates
		case 1: veh_type = getVehicleType(input);
				switch(veh_type){
				    case 0: display_lines = SystemInterface.getCarRates(); break;
				    case 1: display_lines = SystemInterface.getSUVRates(); break;
			      	    case 2: display_lines = SystemInterface.getTruckRates(); break;
				}
				displayResults(display_lines);
				break;

		// display available vehicles
		case 2:	veh_type = getVehicleType(input);
				switch(veh_type){
				    case 0: display_lines = SystemInterface.getAvailCars(); break;
				    case 1: display_lines = SystemInterface.getAvailSUVs(); break;
			      	    case 2: display_lines = SystemInterface.getAvailTrucks(); break;
				}
				displayResults(display_lines);
				break;

		// display estimated rental cost
		case 3:	rental_details = getRentalDetails(input);
				display_lines = SystemInterface.estimatedRentalCost(rental_details);
				displayResults(display_lines);
				break;
		
  		// make a reservation
		case 4:	reserv_details = getReservationDetails(input);                           
				display_lines = SystemInterface.makeReservation(reserv_details);
				displayResults(display_lines);
				break;
		
		// cancel a reservation
		case 5:	vin = getVIN(input);
				display_lines = SystemInterface.cancelReservation(vin);
				displayResults(display_lines);
				break;

		// view corporate account (and company reservations)
		case 6:	acct_num = getAcctNumber(input);
				display_lines = SystemInterface.getAccount(acct_num);
				displayResults(display_lines);
				break;

		// process returned vehicle
		case 7:	acct_num = getAcctNumber(input);
				vin = getVIN(input);
                                System.out.println("Enter number of days used > ");
                                int num_days_used = input.nextInt();
                                System.out.println("Enter number of miles driven > ");
                                int num_miles_driven = input.nextInt();
				display_lines = SystemInterface.processReturnedVehicle(vin, num_days_used,num_miles_driven);
				displayResults(display_lines);
				break;

		// quit program
		case 8: quit = true;
            }
        }
	// ------- private methods

	private void displayMenu() {
            System.out.println("1 – View Current Rates	...	displays rental (and insurance rates)"); //
            System.out.println(" 	     for one of cars, SUVs, or trucks ");
            System.out.println("2 – View Available Vehicles	... 	displays available vehicles (cars, SUVs, or "); //
            System.out.println("  		trucks");
            System.out.println("3 – Calc Estimated Rental Cost	... 	displays estimated rental cost for given vehicle "); //
            System.out.println(" 		type, rental period, expected miles driven,");
            System.out.println(" 		optional daily insurance, and if Prime Customer ");
            System.out.println("4 – Make a Reservation	...	creates a reservation for VIN, account number,");
            System.out.println(" 	     rental period, and insur option");
            System.out.println("5 - Cancel Reservation	...  cancels a reservation by VIN");
            System.out.println("6 – View Corporate Account	... 	displays account information for a given account");
            System.out.println("		number, including all current reservations");
            System.out.println("7 – Process Returned Vehicle	...  requests VIN and actual number of miles driven");
            System.out.println(" 	     and processes returned vehicle and displays");
            System.out.println("                                  	total charge");
            System.out.println("8 - Quit");
        }

	private int getSelection(Scanner input) {
            int i = 0;
            while(i < 1 || i > 8){
                System.out.println("Select a number >");
                i = input.nextInt();
            }
            return i;
        }
        
        private String getAcctNumber(Scanner input){         
            String a = "";
            while(a.length() != 5 || !a.matches("[0-9]*")){
                System.out.println("Enter a 5 digit account number >");
                a = input.next();
            }
            return a;
        }

	private String getVIN(Scanner input){
            System.out.println("Enter a VIN >");
            return input.next();
        }

	private int getVehicleType(Scanner input){
            System.out.println("Cars - 1");
            System.out.println("SUVs - 2");
            System.out.println("Trucks - 3");
            System.out.println("Select a vehicle type with numbers 1-3 > ");
            int i = input.nextInt();
            if(i < 1 || i > 3){
                return getVehicleType(input);
            }
            else {
                return i - 1;
            }
        }

	private RentalDetails getRentalDetails(Scanner input)
	// prompts user to enter required information for an estimated rental cost (vehicle type, estimated  
 	// number of miles expected to be driven, rental period (number of days, weeks or months), and
 	// insurance option, returning the result packaged as a RentalDetails object (to be passed in method
 	// calls to the SystemInterface)
        { 
            int vType = getVehicleType(input);
            System.out.println("Enter Number of miles vehicle is driven >");
            int m = input.nextInt();
            System.out.println("Enter a rental period >");
            String rp = input.next();
            System.out.println("Is vehicle insured? yes/no >");
            boolean isInsured = input.next().equals("yes");
            System.out.println("Is customer a prime customer? yes/no >");
            boolean isPrimeCustomer = input.next().equals("yes");
            return new RentalDetails(vType, rp, m, isInsured, isPrimeCustomer);
        }

	private ReservationDetails getReservationDetails(Scanner input)
	// prompts user to enter required information for making a reservation (VIN of vehicle to reserve, 
 	// acct number, rental period, and insurance option), returning the result packaged as a 
 	// ReservationDetails object (to be passed in method calls to the SystemInterface)
        { 
            boolean isInsured = false;
            System.out.println("Enter a VIN>");
            String v = input.next();
            System.out.println("Enter a 5 digit account number >");
            String a = input.next();
            System.out.println("Enter a rental period >");
            String r = input.next();
            System.out.println("Does the vehicle have daily insurance? yes/no >");
            isInsured = input.next().equals("yes");
            return new ReservationDetails(v, a, r, isInsured);
        }

	private void displayResults(String[] lines){ 
            for (int i = 0; i < lines.length; i++){
                System.out.println(lines[i]);
            }
        }
}

