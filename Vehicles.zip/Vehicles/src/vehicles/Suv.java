
package vehicles;

public class Suv extends Vehicle{
    private int capacity;
    private int cargo;
    public Suv(String d, int m, String v, int c, int k){
        super(d, m, v);
        capacity = c;
        cargo = k;
    }
    
    public String toString(){
        return getDescript() + " (SUV) MPG: " + getMPG() + " Seating: " + getSeatingCapacity() + " Storage: " + getCargoCapacity() + " cu. ft. VIN: " + getVIN();
    }
    public int getSeatingCapacity(){
        return capacity;
    }
    
    public int getCargoCapacity(){
        return cargo;
    }
}
