
package vehicles;

public class Rates {
    private VehicleRates[]  rates = new VehicleRates[3];    // array of size 3 to store rates for three types of vehicles
    //constructor – passed CarRates, SUVRates and TruckRates objects to assign in vehicle_rates array.
    
    public Rates(CarRates c, SUVRates s, TruckRates t){
        rates[0] = c;
        rates[1] = s;
        rates[2] = t;
    }
    
    public VehicleRates  getCarRates() {
        return rates[0];
    }
    public VehicleRates  getSUVRates() {
        return rates[1];
    }
    public VehicleRates  getTruckRates() {
        return rates[2];
    }
    
    public void setCarRates(VehicleRates CR){
        rates[0] = CR;
    }
    public void setSUVRates(VehicleRates SR){
        rates[1] = SR;
    }
    public void setTruckRates(VehicleRates VR){
        rates[2] = VR;
    }

    public double calcEstimatedCost(int vehicleType, String estimatedRentalPeriod, int estimatedNumMiles, boolean dailyInsur, boolean primeCustomer) {
        VehicleRates r = rates[vehicleType];
        double cost = 0;
        int periodNum = Integer.parseInt(estimatedRentalPeriod.substring(1));
        switch(estimatedRentalPeriod.substring(0, 1)){
            case "D" : cost += periodNum * r.getDailyRate();
            if (dailyInsur)cost += periodNum * r.getDailyInsurRate();
            break;
            case "W" : cost += periodNum * r.getWeeklyRate();
            if (dailyInsur)cost += 7 * periodNum * r.getDailyInsurRate();
            break;
            case "M" : cost += periodNum * r.getMonthlyRate();
            if (dailyInsur)cost += 30 * periodNum * r.getDailyInsurRate();
            break;
        }
        if(primeCustomer && estimatedNumMiles > 100){
            cost += (estimatedNumMiles - 100) * r.getMileageChrg();
        }
        if(!primeCustomer){
            cost += estimatedNumMiles * r.getMileageChrg();
        } 
        return cost;
    }
	
    public double calcActualCost(Cost rates, int numDaysUsed, int NumMilesDriven, boolean dailyInsur, boolean primeCustomer) {
        double cost = 0;
        if(numDaysUsed < 7){
            cost += numDaysUsed * rates.getDailyRate();
        }
        if(numDaysUsed >= 7 && numDaysUsed < 30){
            cost += numDaysUsed * rates.getWeeklyRate() / 7;
        }
        if(numDaysUsed >= 30){
            cost += numDaysUsed * rates.getMonthlyRate() / 30;
        }
        if(primeCustomer && NumMilesDriven > 100){
            cost += (NumMilesDriven - 100) * rates.getMileageChrg();
        }
        if(!primeCustomer){
            cost += NumMilesDriven * rates.getMileageChrg();
        }       
        if (dailyInsur) cost += numDaysUsed * rates.getDailyInsurRate();
        return cost;
    }

}
