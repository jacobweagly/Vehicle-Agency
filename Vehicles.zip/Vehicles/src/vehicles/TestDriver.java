
package vehicles;
import java.util.*;

public class TestDriver {
    public static void main(String[] args){
//        Vehicles place = new Vehicles();
//        place.add(new Car("Chevrolet Camaro - 2018", 30, "HK4GM4565GD", 2));
//        place.add(new Car("Ford Fusion - 2019", 34, "AB4FG5689GM", 4));
//        place.add(new Car("Ford Fusion Hybrid - 2017", 32, "KU4EG3245RW", 4));
//        place.add(new Car("Chevrolet Impala - 2019", 30, "RK3BM4256YH", 4));
//        place.add(new Suv("Honda Odyssey - 2020", 28, "VM9RF2635TD", 7, 6));
//        place.add(new Suv("Dodge Caravan - 2019", 25, "QK3FL4273ME", 5, 4));
//        place.add(new Suv("Ford Expedition - 2018", 20, "JK2RT9364HY", 5, 3));
//        place.add(new Truck("Ten-Foot", 12, "EJ5KU2435BC", 2810));
//        place.add(new Truck("Seventeen-Foot", 10, "KG4DM5472RK", 5930));
//        place.add(new Truck("Twenty-Four-Foot", 8, "EB2WR3082QB", 6500));
//        place.add(new Truck("Twenty-Four-Foot", 8, "TW3GH4290EK", 6500));
//        place.getVehicle("HK4GM4565GD").reserve(new Reservation("1111 1111 1111 1111", "1 week" , true));
//        place.getVehicle("AB4FG5689GM").reserve(new Reservation("2111 1111 1111 1111", "1 week" , true));
//        place.getVehicle("KU4EG3245RW").reserve(new Reservation("2211 1111 1111 1111", "1 week" , true));
//        System.out.println("All");
//        place.displayAll();
//        System.out.println("Available");
//        place.displayAvailable();     
//        System.out.println(place.getVehicle("HK4GM4565GD").getReservation());
//        place.getVehicle("HK4GM4565GD").cancelReservation();
//        place.remove("VM9RF2635TD");


          // STAGE 1
//          try{
//                Accounts accts = new Accounts();
//                accts.add(new Account("67890", "Company inc.", true));
//                accts.add(new Account("68888", "Not Company inc.", false));
//                accts.add(new Account("69999", "Not Company inc.", false));
//                accts.add(new Account("60000", "Not Company inc.", false));
//                Account single_acct = accts.getAccount("67890");
//                System.out.println("Account 67890: " + single_acct);
//                while(accts.hasNext()){
//                    System.out.println(accts.getNext().getAccount());
//                }
//          }
//          catch (Exception ex){
//              System.out.print(ex);
//          }

           // STAGE 2
//            Rates rs = new Rates(null, null, null);
//            Vehicles place = new Vehicles();
//            Accounts accts = new Accounts();
//            Transactions trs = new Transactions();
//            place.add(new Car("Chevrolet Camaro - 2018", 30, "HK4GM4565GD", 2));
//            place.add(new Car("Ford Fusion - 2019", 34, "AB4FG5689GM", 4));
//            place.add(new Car("Ford Fusion Hybrid - 2017", 32, "KU4EG3245RW", 4));
//            place.add(new Car("Chevrolet Impala - 2019", 30, "RK3BM4256YH", 4));
//            place.add(new Suv("Honda Odyssey - 2020", 28, "VM9RF2635TD", 7, 6));
//            place.add(new Suv("Dodge Caravan - 2019", 25, "QK3FL4273ME", 5, 4));
//            place.add(new Suv("Ford Expedition - 2018", 20, "JK2RT9364HY", 5, 3));
//            place.add(new Truck("Ten-Foot", 12, "EJ5KU2435BC", 2810));
//            place.add(new Truck("Seventeen-Foot", 10, "KG4DM5472RK", 5930));
//            place.add(new Truck("Twenty-Four-Foot", 8, "EB2WR3082QB", 6500));
//            place.add(new Truck("Twenty-Four-Foot", 8, "TW3GH4290EK", 6500));
//            SystemInterface.initSystem(rs, place, accts, trs);
//            SystemInterface.updateCarRates(24.95, 149.95, 514.95, 0.15, 14.95);
//            SystemInterface.updateSUVRates(29.95, 189.95, 579.95, 0.15, 14.95);
//            SystemInterface.updateTruckRates(34.95, 224.95, 797.95, 0.15, 14.95);
//            SystemInterface.addAccount("67890", "Company inc.", true);
//            SystemInterface.addAccount("68888", "Not Company inc.", false);
//            SystemInterface.addAccount("69999", "Not Company inc.", false);
//            SystemInterface.addAccount("60000", "Not Company inc.", false);
//            SystemInterface.makeReservation("HK4GM4565GD", "67890", "W4", true);
//            SystemInterface.makeReservation("KG4DM5472RK", "67890", "W4", true);
//            SystemInterface.cancelReservation("KG4DM5472RK");
//            SystemInterface.processReturnedVehicle("HK4GM4565GD", 8, 500);
//            Arrays.stream(SystemInterface.getCarRates()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getSUVRates()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getTruckRates()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.estimatedRentalCost(0, "D4", 55, true, true)).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getAllVehicles()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getAvailCars()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getAvailSUVs()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getAvailTrucks()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getReservation("HK4GM4565GD")).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getAllReservations()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getAccount("67890")).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getAllAccounts()).forEach(System.out::println);
//            Arrays.stream(SystemInterface.getAllTransactions()).forEach(System.out::println);
            
            // STAGE 3
            
            Rates rs = new Rates(null, null, null);
            Vehicles place = new Vehicles();
            Accounts accts = new Accounts();
            Transactions trs = new Transactions();
            SystemInterface.initSystem(rs, place, accts, trs);
            place.add(new Car("Chevrolet Camaro - 2018", 30, "HK4GM4565GD", 2));
            place.add(new Car("Ford Fusion - 2019", 34, "AB4FG5689GM", 4));
            place.add(new Car("Ford Fusion Hybrid - 2017", 32, "KU4EG3245RW", 4));
            place.add(new Car("Chevrolet Impala - 2019", 30, "RK3BM4256YH", 4));
            place.add(new Suv("Honda Odyssey - 2020", 28, "VM9RF2635TD", 7, 6));
            place.add(new Suv("Dodge Caravan - 2019", 25, "QK3FL4273ME", 5, 4));
            place.add(new Suv("Ford Expedition - 2018", 20, "JK2RT9364HY", 5, 3));
            place.add(new Truck("Ten-Foot", 12, "EJ5KU2435BC", 2810));
            place.add(new Truck("Seventeen-Foot", 10, "KG4DM5472RK", 5930));
            place.add(new Truck("Twenty-Four-Foot", 8, "EB2WR3082QB", 6500));
            place.add(new Truck("Twenty-Four-Foot", 8, "TW3GH4290EK", 6500));
            SystemInterface.updateCarRates(24.95, 149.95, 514.95, 0.15, 14.95);
            SystemInterface.updateSUVRates(29.95, 189.95, 579.95, 0.15, 14.95);
            SystemInterface.updateTruckRates(34.95, 224.95, 797.95, 0.15, 14.95); 
            SystemInterface.addAccount("67890", "Company inc.", true);
            SystemInterface.addAccount("68888", "Not Company inc.", false);
            SystemInterface.addAccount("69999", "Not Company inc.", false);
            SystemInterface.addAccount("60000", "Not Company inc.", false);
            EmployeeUI me = new EmployeeUI();
            //ManagerUI me = new ManagerUI();
            me.start();
            
            
    }
}
