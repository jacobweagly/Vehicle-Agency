/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author Jacob
 */
public abstract class Vehicle {
    private String description;
    private int mpg;
    private String vin;
    private Reservation resv;
    private Cost ct;
    
    public Vehicle(String d, int m, String v){
        description = d;
        mpg = m;
        vin = v;
        resv = null;
        ct = null;
    }
    
    public String getDescript(){return description;}   
    public int getMPG() {return mpg;}
    public String getVIN() {return vin;}
    public Reservation getReservation() {return resv;}
    public Cost getCost(){
        return ct;
    }
    public abstract String toString(); // ABSTRACT METHOD – implemented in each subclass
    public boolean isReserved() {return resv != null;}
    public void reserve(Reservation r) {
        resv = r;
    }
    public void setCost(Cost cost){        
        ct = cost;
    }
    public void cancelReservation() {resv = null;}    
}
