
package vehicles;

import java.util.Scanner;
import java.util.Random;

public class ManagerUI implements UserInterface{
    
    public void start() {

	int selection;
        Scanner input = new Scanner(System.in);
	boolean quit = false;

	// command loop
	while(!quit) {
		displayMenu();
		selection = getSelection(input);
                quit = selection == 7;
		execute(selection, input, quit);
	}
    }
    
    private void execute(int selection, Scanner input, boolean quit) {

        int veh_type;
	String vin, acct_num;  String[] display_lines = {""};
	RentalDetails rental_details;  ReservationDetails reserv_details;

	switch(selection) {

		// display rental rates
		case 1: 
                            displayResults(SystemInterface.getCarRates());
                            displayResults(SystemInterface.getSUVRates());
                            displayResults(SystemInterface.getTruckRates());
                            veh_type = getVehicleType(input);
				switch(veh_type){
				    case 0: 
                                        System.out.println("Enter daily rate >");
                                        double d1 = input.nextDouble();
                                        System.out.println("Enter weekly rate >");
                                        double w1 = input.nextDouble();
                                        System.out.println("Enter monthly rate >");
                                        double m1 = input.nextDouble();
                                        System.out.println("Enter cost per mile >");
                                        double mi1 = input.nextDouble();
                                        System.out.println("Enter insurance rate >");
                                        double i1 = input.nextDouble();
                                        SystemInterface.updateCarRates(d1, w1, m1, mi1, i1);
                                        break;
				    case 1: 
                                        System.out.println("Enter daily rate >");
                                        double d2 = input.nextDouble();
                                        System.out.println("Enter weekly rate >");
                                        double w2 = input.nextDouble();
                                        System.out.println("Enter monthly rate >");
                                        double m2 = input.nextDouble();
                                        System.out.println("Enter cost per mile >");
                                        double mi2 = input.nextDouble();
                                        System.out.println("Enter insurance rate >");
                                        double i2 = input.nextDouble();
                                        SystemInterface.updateCarRates(d2, w2, m2, mi2, i2);
                                        break;
			      	    case 2: 
                                        System.out.println("Enter daily rate >");
                                        double d3 = input.nextDouble();
                                        System.out.println("Enter weekly rate >");
                                        double w3 = input.nextDouble();
                                        System.out.println("Enter monthly rate >");
                                        double m3 = input.nextDouble();
                                        System.out.println("Enter cost per mile >");
                                        double mi3 = input.nextDouble();
                                        System.out.println("Enter insurance rate >");
                                        double i3 = input.nextDouble();
                                        SystemInterface.updateCarRates(d3, w3, m3, mi3, i3);
                                        break;
				}
				displayResults(display_lines);
				break;

		// display available vehicles
		case 2:	veh_type = getVehicleType(input);
				switch(veh_type){
				    case 0: display_lines = SystemInterface.getAvailCars(); break;
				    case 1: display_lines = SystemInterface.getAvailSUVs(); break;
			      	    case 2: display_lines = SystemInterface.getAvailTrucks(); break;
				}
				displayResults(display_lines);
				break;

		// display estimated rental cost
		case 3:	
                                System.out.println("Enter company name >");
                                String c = input.next();
                                System.out.println("Is this company a prime customer? yes/no >");
                                boolean primeCustomer = input.next().equals("yes");
				display_lines = SystemInterface.addAccount(generateAcctNumber(), c, primeCustomer);
				displayResults(display_lines);
				break;
		
  		// make a reservation
		case 4:	
				display_lines = SystemInterface.getAllReservations();
				displayResults(display_lines);
				break;
		
		// cancel a reservation
		case 5:
				display_lines = SystemInterface.getAllAccounts();
				displayResults(display_lines);
				break;

		// view corporate account (and company reservations)
		case 6:	
				display_lines = SystemInterface.getAllTransactions();
				displayResults(display_lines);
				break;

		// quit program
		case 7:
                    quit = true;
            }
        }
    
    private void displayMenu() {
            System.out.println("1 – View and update current rates"); //
            System.out.println("2 – View Available Vehicles"); //
            System.out.println("3 – Add Account"); //
            System.out.println("4 - View reservations"); //
            System.out.println("5 - View all accounts");//
            System.out.println("6 – View all transactions"); //
            System.out.println("7  - quit");
    }
    
    private String generateAcctNumber() {
        Random r = new Random();
        return "" + (r.nextInt(90000) + 10000);
        
    }
    
    private int getVehicleType(Scanner input){
            System.out.println("Cars - 1");
            System.out.println("SUVs - 2");
            System.out.println("Trucks - 3");
            System.out.println("Select a vehicle type with numbers 1-3 > ");
            int i = input.nextInt();
            if(i < 1 || i > 3){
                return getVehicleType(input);
            }
            else {
                return i - 1;
            }
        }
    
    private int getSelection(Scanner input) {
            int i = 0;
            while(i < 1 || i > 7){
                System.out.println("Select a number >");
                i = input.nextInt();
            }
            return i;
        }
    
    private void displayResults(String[] lines){ 
        for (int i = 0; i < lines.length; i++){
            System.out.println(lines[i]);
        }
    }
}
