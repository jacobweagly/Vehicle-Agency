/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author jweagl2
 */
public class TransactionNode {
    private Transaction value;
    private TransactionNode next;
    
    public TransactionNode(Transaction t){
        value = t;
        next = null;
    }
            
    public TransactionNode getNext(){
        return next;
    }
    
    public void setNext(TransactionNode n){
        next = n;
    }
    
    public Transaction getTransaction(){
        return value;
    }
}
