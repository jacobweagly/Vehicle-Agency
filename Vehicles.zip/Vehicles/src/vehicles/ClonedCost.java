/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author Jacob
 */
public class ClonedCost implements Cost{
    private double daily_rate, weekly_rate, monthly_rate, mileage_chrg, daily_insur_rate;

    public ClonedCost(double daily_rate, double weekly_rate, double monthly_rate, double mileage_chrg, double daily_insur_rate){
        this.daily_rate = daily_rate;
        this.weekly_rate = weekly_rate;
        this.monthly_rate = monthly_rate;
        this.mileage_chrg = mileage_chrg;
        this.daily_insur_rate = daily_insur_rate;
    }
    public double getDailyRate()		// cost per day
    {
        return daily_rate;
    }
    public double getWeeklyRate()       	// cost per week
    {
        return weekly_rate;
    }
    public double getMonthlyRate()       	// cost per month
    {
        return monthly_rate;
    }
    public double getMileageChrg()      	// cost per mile, based on vehicle type  
    {
        return mileage_chrg;
    }
    public double getDailyInsurRate()  	// insurance cost (per day)
    {
        return daily_insur_rate;
    }
}
