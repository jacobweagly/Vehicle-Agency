 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author Jacob
 */
public class Reservation {
    private String creditCardNum;
    private String rentalPeriod;
    private boolean insuranceSelected;
    
    public Reservation(String c, String r, boolean i){
        creditCardNum = c;
        rentalPeriod = r;
        insuranceSelected = i;
    }
    
    public String getCreditCardNum(){
        return creditCardNum;
    }
    
    public String getRentalPeriod(){
        return rentalPeriod;
    }
    
    public boolean isInsureanceSelected(){
        return insuranceSelected;
    }
    
    public String toString(){
        return "Credit Card Number: " + creditCardNum + " Period: " + rentalPeriod + ". Insurance " + (insuranceSelected  ? "wanted" : "not wanted");
    }
}
