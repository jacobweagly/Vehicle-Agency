/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author jweagl2
 */
public class AccountNode {
    private Account value;
    private AccountNode next;
    
    public AccountNode(Account a){
        value = a;
        next = null;
    }
            
    public AccountNode getNext(){
        return next;
    }
    
    public void setNext(AccountNode n){
        next = n;
    }
    
    public Account getAccount(){
        return value;
    }
}
