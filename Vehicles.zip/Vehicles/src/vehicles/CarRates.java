
package vehicles;

public class CarRates extends VehicleRates{
    public CarRates(double daily_rate, double weekly_rate, double monthly_rate, double mileage_chrg, double daily_insur_rate){
        super(daily_rate, weekly_rate, monthly_rate, mileage_chrg, daily_insur_rate);
    }
    public String toString(){
        return "Car Rates  Daily: " + getDailyRate() + " Weekly: " + getWeeklyRate() + " Monthly: " + getMonthlyRate() + " Per Mile: " + getMileageChrg() + " Daily Insur: " + getDailyInsurRate();
    }
}
