/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author jweagl2
 */
public class VehicleNode {
    private VehicleNode next;
    private Vehicle value;
    
    public VehicleNode(Vehicle v){
        value = v;
        next = null;
    }
    
    public VehicleNode getNext(){
        return next;
    }
    
    public void setNext(VehicleNode next){
        this.next = next;
    }
    
    public Vehicle getVehicle(){
        return value;
    }
}
