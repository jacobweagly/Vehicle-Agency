/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author jweagl2
 */
public class Accounts {
    private AccountNode head;
    private AccountNode current;
    
    public Accounts(){
        head = new AccountNode(null);
        reset();
    }
    
    public void add(Account v){
        reset();
        AccountNode temp = new AccountNode(v);
        while (hasNext()){
            current = current.getNext();
        }
        current.setNext(temp);  
        reset();
    }
    
    public Account getAccount(String acct_num)
            throws InvalidAcctNumException
            ,AccountNumberNotFoundException
    {
        System.out.println(acct_num);
        reset();
        while(hasNext()){
            System.out.println(current.getNext().getAccount().getAcctNum());
            if(current.getNext().getAccount().getAcctNum() == acct_num){
                if(current.getNext().getAccount().getAcctNum().length() != 5){
                    throw new InvalidAcctNumException("Account number must contain 5 digits. ");
                }
                if(!current.getNext().getAccount().getAcctNum().matches("[0-9]*")){
                    throw new InvalidAcctNumException("Account number must contain only numbers. ");
                }
                return current.getNext().getAccount();
            }
            current = current.getNext();
        }
        //return null;
        throw new AccountNumberNotFoundException("Account not found. ");
    }
    
    public void reset(){
        current = head;
    }
    
    public boolean hasNext(){
        return current.getNext() != null;                
    }
    
    public AccountNode getNext(){
        current = current.getNext();
        return current;
    }
}
