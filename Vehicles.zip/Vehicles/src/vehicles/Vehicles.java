
package vehicles;

public class Vehicles {
    private VehicleNode head;
    private VehicleNode current;
    
    public Vehicles(){
        head = new VehicleNode(null);
        reset();
    }
    
    public void add(Vehicle v){
        reset();
        VehicleNode temp = new VehicleNode(v);
        while (hasNext()){
        }
        current.setNext(temp);  
        reset();
    }

    public void remove(String VIN){
        reset();
        while (current.getNext() != null){
            if(current.getNext().getVehicle().getVIN() == VIN){
                current.setNext(current.getNext().getNext());
            }
            current = current.getNext();
        }
    }
    
    public Vehicle getVehicle(String VIN){
        reset();
        Vehicle v = null;
        while(hasNext()){
            if(current.getVehicle().getVIN() == VIN){
                v = current.getVehicle();
            }
        }
        return v;
    }
    
    public void reset(){
        current = head;
    }
    
    public boolean hasNext(){
        if(current.getNext() != null){
            current = current.getNext();
            return true;
        }
        return false;
    }
    
    public VehicleNode getNext(){
        return current.getNext();
    }
    
    public VehicleNode getCurrent(){
        return current;
    }
    
}
