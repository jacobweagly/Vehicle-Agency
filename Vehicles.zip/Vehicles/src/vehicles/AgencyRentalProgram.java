/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;
import java.util.*;

/**
 *
 * @author Jacob
 */
public class AgencyRentalProgram {
    	public static UserInterface ui;
    public static void main(String[ ] args) {

	Rates rs = new Rates(null, null, null);
        Vehicles place = new Vehicles();
        Accounts accts = new Accounts();
        Transactions trs = new Transactions(); 
        SystemInterface.initSystem(rs, place, accts, trs);
        place.add(new Car("Chevrolet Camaro - 2018", 30, "HK4GM4565GD", 2));
        place.add(new Car("Ford Fusion - 2019", 34, "AB4FG5689GM", 4));
        place.add(new Car("Ford Fusion Hybrid - 2017", 32, "KU4EG3245RW", 4));
        place.add(new Car("Chevrolet Impala - 2019", 30, "RK3BM4256YH", 4));
        place.add(new Suv("Honda Odyssey - 2020", 28, "VM9RF2635TD", 7, 6));
        place.add(new Suv("Dodge Caravan - 2019", 25, "QK3FL4273ME", 5, 4));
        place.add(new Suv("Ford Expedition - 2018", 20, "JK2RT9364HY", 5, 3));
        place.add(new Truck("Ten-Foot", 12, "EJ5KU2435BC", 2810));
        place.add(new Truck("Seventeen-Foot", 10, "KG4DM5472RK", 5930));
        place.add(new Truck("Twenty-Four-Foot", 8, "EB2WR3082QB", 6500));
        place.add(new Truck("Twenty-Four-Foot", 8, "TW3GH4290EK", 6500));
        SystemInterface.updateCarRates(24.95, 149.95, 514.95, 0.15, 14.95);
        SystemInterface.updateSUVRates(29.95, 189.95, 579.95, 0.15, 14.95);
        SystemInterface.updateTruckRates(34.95, 224.95, 797.95, 0.15, 14.95);
        
	Scanner input = new Scanner(System.in);
	boolean quit = false;

	// Create Requested UI and Begin Execution 
	while(!quit) {  // (allows switching between Employee and Manager user interfaces while running)
		ui = getUI(input);
	
		if(ui == null)
			quit = true;
		else {
			// Init System Interface with Agency Data (if not already initialized)
			if(!SystemInterface.initialized())
			      SystemInterface.initSystem(rs, place, accts, trs);
			ui.start();
		}
	}
    }

    public static UserInterface getUI(Scanner input) {
	boolean valid_selection = false;
        int selection;
	while(!valid_selection) {
		System.out.print("1 – Employee, 2 – Manager, 3 – quit: ");

		selection = input.nextInt();
		if(selection == 1) {
			ui = new EmployeeUI();
			valid_selection = true;
		}
		else
		if(selection == 2) {
			ui = new ManagerUI();
			valid_selection = true;
		}
		else
		if(selection == 3) {
			ui = null;
			valid_selection = true;
		}
		else
			System.out.println("Invalid selection – please reenter");
	}
	return ui;
    }
}
