/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author jweagl2
 */
public class Transaction {
    private String acct_num;    // five-digit acct number
    private String company_name;
    private String vehicle_type; // car, SUV or Truck
    private String rental_period; // days, week, months
    private String rental_cost;
    
    public Transaction(String a, String c, String v, String rp, String rc){
        acct_num = a;
        company_name = c;
        vehicle_type = v;
        rental_period = rp;
        rental_cost = rc;
    }

    public String toString() {
        return "Account Number: " + acct_num + " Company: " + company_name + " Vehicle Type: " + vehicle_type + " Rental Period: " + rental_period + " Cost: " + rental_cost; 
    }
}
