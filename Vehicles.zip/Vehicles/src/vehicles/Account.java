/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicles;

/**
 *
 * @author jweagl2
 */
public class Account{
    private String acct_num;    // five-digit acct number
    private String company_name;
    private boolean prime_customer;
    
    public Account(String a, String c, boolean p){
        acct_num = a;
        company_name = c;
        prime_customer = p;
    }

    public String getAcctNum() {   
        return acct_num;
    }
    
    public String getCompanyName(){
        return company_name;
    }
    
    public boolean primeCustomer() {
        return prime_customer;
    }
    public String toString() {
        return "Account Number: " + acct_num + " Company: " + company_name + ( prime_customer ? " Prime Customer" : ""); 
    }
}
