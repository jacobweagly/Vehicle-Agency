
package vehicles;

public class ReservationDetails {
    
    private String VIN;
    private String acct_num;
    private String rentalPeriod;
    private boolean dailyInsur;
    
            
    public ReservationDetails(String v, String a, String r, boolean d){       
        VIN = v;
        acct_num = a;
        rentalPeriod = r;
        dailyInsur = d;
    }
    
    public String getVIN(){
        return VIN;
    }
    
    public String getAcct_num(){
        return acct_num;
    }
    
    public String getRentalPeriod(){
        return rentalPeriod;
    }
    
    public boolean isInsured(){
        return dailyInsur;
    }
}
